
export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center text-center p-10">
      <h1 className="text-4xl font-bold">Ashmit Portfolio Placeholder</h1>
      <p className="text-gray-400 mt-4">Your final portfolio component will replace this.</p>
    </div>
  )
}
